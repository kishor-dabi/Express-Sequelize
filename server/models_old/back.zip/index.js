const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const cors = require('cors');
var jwt = require('jsonwebtoken');
require('dotenv').config();
const env = process.env.NODE_ENV || 'local';
const config = require(__dirname + '/server/config/config.json')[env];
const sendResponse = require('./server/services/response.service').response;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : false}));

// CORS
app.use(cors());

app.get('/',(req, res)=>{
  return res.send("ok");
})

app.use((req, res, next) => {
  // if (req.path == '/api/signup' || req.path == '/api/login' || '/api/verify-signup-otp') {
    
  //   next();  
  // }else 
  if (!req.headers.authorization) {
    return res.status(403).json({ message: 'Header missing!' });
  }else{

    // var decoded = jwt.verify(token, 'shhhhh');
    let token = req.headers.authorization
    token = token ? token.split(" ") : [];
    if (token[0].toLocaleLowerCase() == 'auth') {
      if (req.path == '/api/signup' || req.path == '/api/login' || req.path == '/api/verify-signup-otp' || req.path == '/api/forgot-password' || req.path == '/api/resend-otp' || req.path == '/api/verify-otp' || req.path == '/api/reset-password' || req.path == "/api/policy/terms-and-condition") {
        next();  
      }else{
        return sendResponse(res,100,false,'server middleware error.')
      }
    } else if (token[0].toLocaleLowerCase() == 'bearer' && token[1]) {
    	jwt.verify(token[1], config.jwt, function(err, decoded) {
		  // console.log(decoded) // bar
		  if (decoded) {
    		next()

		  } else {
	    	return res.status(401).json({ message: 'Invalid token.' });

		  }
		});
    }else{
    	return res.status(403).json({ message: 'Unauthorized' });

    }

  }
})
require('./server/routes')(app);
const db = require("./server/models");

db.sequelize.sync({logging: false,}).then(function(){
    // console.log("-------------------------");
  }
  );

db.sequelize.authenticate().then(() => {
        console.log('Connected to SQL database:', config.database);
    })
    .catch(err => {
        console.error('Unable to connect to SQL database:', config.database, err);
    });


const PORT = config.server_port || 4000;
app.listen(PORT,() => {
    console.log(`Server is listening to port ${PORT}`)
})