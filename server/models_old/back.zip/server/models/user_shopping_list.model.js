
module.exports = (sequelize, Sequelize) => {
    const UserShoppingList = sequelize.define("UserShoppingList", {
        user_shopping_list_id:{
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        // user_id:{
        //     type: Sequelize.INTEGER
        // },
        week_start_date:{
            type: Sequelize.DATE,
            defaultValue: null 
        },
        week_end_date:{
            type: Sequelize.DATE ,
            defaultValue: null
        },
        ingredient_quantity:{
            type: Sequelize.INTEGER,
            defaultValue: null
        },
        ingredient_quantity_unit:{
            type: Sequelize.STRING,
            defaultValue: null
        },
        ingredient_metric_quantity:{
            type: Sequelize.INTEGER,
            defaultValue: null
        },
        ingredient_metric_quantity_unit:{
            type: Sequelize.STRING,
            defaultValue: null
        }
        
    }, {
        paranoid: true,
        deletedAt: "deletedAt",
        timestamps: true,
        tableName: "user_shopping_lists"
    });

    UserShoppingList.associate = function(models) {
        // Subscription.belongsToMany(models.User, { through: models.UserSubscription, foreignKey: 'subscription_id' });
    }


    return UserShoppingList;
};