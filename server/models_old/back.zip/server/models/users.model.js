
module.exports = (sequelize, Sequelize) => {
    const User = sequelize.define("User", {
        user_id:{
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        full_name: {
            type: Sequelize.STRING
        },
        email: {
            type: Sequelize.STRING
        },
        phone_number: {
            type: Sequelize.STRING//DATE
        },
        password: {
            type: Sequelize.STRING
        },
        avatar_image_url: {
            type: Sequelize.STRING
        },
        height_id: {
            type: Sequelize.INTEGER
        },
        weight_id: {
            type: Sequelize.INTEGER
        },
        is_verified: {
            type: Sequelize.BOOLEAN,
            defaultValue:false
        },
        gender: {
            type: Sequelize.INTEGER
        },
        // level_of_exercise_id: {
        //     type: Sequelize.INTEGER
        // },
        age: {
            type: Sequelize.INTEGER,
            defaultValue: null
        },
        status:{
            type: Sequelize.INTEGER,
            defaultValue: null
        },
        social_login_id:{
            type: Sequelize.STRING,
            defaultValue: null
        },
        signup_type:{
            type: Sequelize.INTEGER, // 1=>email 2=>fb 3=>google 4=>apple,
            defaultValue: null
        },
        user_type:{
            type: Sequelize.INTEGER, // 1=>admin 2=>users
            defaultValue: null
        },
        user_steps:{
            type: Sequelize.INTEGER,
            defaultValue: null
        }
    }, {
        paranoid: true,
        deletedAt: "deletedAt",
        timestamps: true,
        tableName: "users"
    });

  
    User.associate = function(models) {
        User.belongsTo(models.MealCollection, {
          foreignKey: 'meal_collection_id',
          as: 'meal_collection'
        });
        User.belongsTo(models.LevelOfExercise, {
            foreignKey: 'level_of_exercise_id',
            as: 'level_of_exercise'
        });
        User.belongsTo(models.MajorGoalTypes, {
            foreignKey: 'major_goal_type_id',
            as: 'major_goal'
        });
        User.belongsTo(models.Weight, {
            foreignKey: 'goal_weight_id',
            as: 'goal_weight',
            key: "weight_id"
        });
        // User.belongsTo(models.UserDevice,{
        //     foreignKey: 'user_id',
        //     as:'devices', onDelete : "CASCADE", onUpdate : "CASCADE"

        // });
        
        
        User.belongsToMany(models.ProteinSource, { through: models.UserProteinSource, foreignKey: 'user_id' });
        
        User.belongsToMany(models.Recipe, { through: models.UserFavouriteFood, foreignKey: 'user_id' });
        User.belongsToMany(models.Allergies, { through: models.UserAllergy, foreignKey: 'user_id', onDelete : "CASCADE", onUpdate : "CASCADE" });
        User.belongsToMany(models.GoalType, { through: models.UserGoalPlan, foreignKey: 'user_id' });
        User.belongsToMany(models.Subscription, { through: models.UserSubscription, foreignKey: 'user_id' });
        User.belongsToMany(models.MealType, { through: models.UserMeal, foreignKey: 'user_id' });
        User.belongsToMany(models.DislikeFood, { through: models.UserDislikeFood, foreignKey: 'user_id' });
        
        User.belongsToMany(models.Ingredient, { through: models.UserShoppingList, foreignKey: 'user_id' });
        
        
    }

    // User.associate = function(models) {
    //     User.belongsToMany(models.Allergies, { through: "UserAllergies" });
    // }    
    return User;
};