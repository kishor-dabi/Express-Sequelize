
module.exports = (sequelize, Sequelize) => {
    const HelpCategory = sequelize.define("HelpCategory", {
        help_categorie_id:{
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        category_name: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        status: {
            type: Sequelize.INTEGER, //,
            defaultValue: null
        }
    }, {
        paranoid: true,
        deletedAt: "deletedAt",
        timestamps: true,
        tableName: "help_categories"
    });


    return HelpCategory;
};