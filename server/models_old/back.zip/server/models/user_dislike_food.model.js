
module.exports = (sequelize, Sequelize) => {
    const UserDislikeFood = sequelize.define("UserDislikeFood", {
        user_dislike_food_id:{
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
     
    }, {
        paranoid: true,
        deletedAt: "deletedAt",
        timestamps: true,
        tableName: "user_dislike_foods"
    });


    return UserDislikeFood;
};