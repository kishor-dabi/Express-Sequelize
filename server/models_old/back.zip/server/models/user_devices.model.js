
module.exports = (sequelize, Sequelize) => {
    const UserDevice = sequelize.define("UserDevice", {
        user_device_id:{
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        user_id:{
            type: Sequelize.INTEGER,
            defaultValue: null
        },
        token_id: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        token: {
            type: Sequelize.TEXT,
            defaultValue: null
        },
        device_name: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        os_version: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        app_version: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        model_name: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        status: {
            type: Sequelize.INTEGER,
            defaultValue: null
        }
    }, {
        paranoid: true,
        deletedAt: "deletedAt",
        timestamps: true,
        tableName: "user_devices"
    });

    UserDevice.associate = function(models) {

        // UserDevice.hasMany(models.User,{
        //     foreignKey: 'user_id',
        //     as:'users',
        //     onDelete : "CASCADE", onUpdate : "CASCADE"
        // });

    }    


    return UserDevice;
};