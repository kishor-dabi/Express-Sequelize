
module.exports = (sequelize, Sequelize) => {
    const BigoCollection = sequelize.define("BigoCollection", {
        collection_id:{
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        bigo_CollectionID:{
            type: Sequelize.INTEGER,
            defaultValue: null
            // unique:true
        },
        title: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        description: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        photo_url: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        dump: {
            type: Sequelize.STRING,
            defaultValue: null
        }
    }, {
        paranoid: true,
        deletedAt: "deletedAt",
        timestamps: true,
        tableName: "bigo_collections"
    });


    return BigoCollection;
};