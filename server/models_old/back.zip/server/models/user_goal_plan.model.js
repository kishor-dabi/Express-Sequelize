
module.exports = (sequelize, Sequelize) => {
    const UserGoalPlan = sequelize.define("UserGoalPlan", {
        user_goal_plan_id:{
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        // user_id: {
        //     type: Sequelize.STRING
        // },
        user_goal_name: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        status: {
            type: Sequelize.INTEGER ,
            defaultValue: null
        }, 
        goal_date: {
            type: Sequelize.DATE,
            defaultValue: null
        },
        goal_time: {
            type: Sequelize.TIME,
            defaultValue: null 
        }
    }, {
        paranoid: true,
        deletedAt: "deletedAt",
        timestamps: true,
        tableName: "user_goal_plans"
    });

    return UserGoalPlan;
};