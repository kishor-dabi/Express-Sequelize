
module.exports = (sequelize, Sequelize) => {
    const Recipe = sequelize.define("Recipe", {
        recipe_id:{
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        bigo_RecipeID:{
            type: Sequelize.INTEGER,
            defaultValue: null,
            // unique:true
        },
        recipe_name: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        recipe_description: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        bigo_ImageURL: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        ingredients: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        steps: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        nutritions: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        bigo_collectionID: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        dump: {
            type: Sequelize.STRING,
            defaultValue: null
        }
    }, {
        paranoid: true,
        deletedAt: "deletedAt",
        timestamps: true,
        tableName: "recipes"
    });

    Recipe.associate = function(models) {
    
        Recipe.belongsToMany(models.User, { through: models.UserFavouriteFood, foreignKey: 'recipe_id' });
    
        Recipe.belongsToMany(models.UserMealPlan, { through: models.UserMealRecipe, foreignKey: 'recipe_id' });
        
        Recipe.belongsToMany(models.Ingredient, { through: models.RecipeIngredient, foreignKey: 'recipe_id' });
    
    }
    


    return Recipe;
};