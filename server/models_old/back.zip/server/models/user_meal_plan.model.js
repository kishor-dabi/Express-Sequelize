

module.exports = (sequelize, Sequelize) => {
    const UserMealPlan = sequelize.define("UserMealPlan", {
        user_meal_plan_id:{
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        meal_count:{
            type: Sequelize.INTEGER,
            defaultValue: null
        },
        date: {
            type: Sequelize.DATE,
            defaultValue: null
        }
    }, {
        paranoid: true,
        deletedAt: "deletedAt",
        timestamps: true,
        tableName: "user_meal_plans"
    });

    UserMealPlan.associate = function(models) {
        UserMealPlan.belongsToMany(models.Recipe, { through: models.UserMealRecipe, foreignKey: 'user_meal_plan_id' });
    }

    return UserMealPlan;
};