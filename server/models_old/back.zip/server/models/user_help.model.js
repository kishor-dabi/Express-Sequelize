
module.exports = (sequelize, Sequelize) => {
    const UserHelp = sequelize.define("UserHelp", {
        help_id:{
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        name: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        email: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        phone_number: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        description: {
            type: Sequelize.STRING,
            defaultValue: null
        },
        help_reply: {
            type: Sequelize.STRING,
            defaultValue: null
        },
       
        status:{
            type: Sequelize.INTEGER, //1->open, 2->resolved,
            defaultValue: null
        }
    }, {
        paranoid: true,
        deletedAt: "deletedAt",
        timestamps: true,
        tableName: "user_helps"
    });

  
    UserHelp.associate = function(models) {
        UserHelp.belongsTo(models.User, {
          foreignKey: 'user_id'
        });
        UserHelp.belongsTo(models.HelpCategory, {
            foreignKey: 'help_category_id',
        });
       
    }
   
    return UserHelp;
};