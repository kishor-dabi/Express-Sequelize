'use strict';
module.exports = {
  up: function(queryInterface, Sequelize) {
    return queryInterface.bulkInsert('level_of_exercises', 
        [
            {
                "exercise_name":"No Activity",
                "createdAt": Sequelize.literal('NOW()'),
                "updatedAt": Sequelize.literal('NOW()')
            },
            {
                "exercise_name":"Light Activity",
                "createdAt": Sequelize.literal('NOW()'),
                "updatedAt": Sequelize.literal('NOW()')
            },
            {
                "exercise_name":"Moderate Activity",
                "createdAt": Sequelize.literal('NOW()'),
                "updatedAt": Sequelize.literal('NOW()')
            },
            {
                "exercise_name":"Very Active",
                "createdAt": Sequelize.literal('NOW()'),
                "updatedAt": Sequelize.literal('NOW()')
            }
        ]
    , {});
  },
  down: function(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('level_of_exercises', null, {});
  }
};









