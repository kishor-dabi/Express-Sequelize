'use strict';
module.exports = {
  up: function(queryInterface, Sequelize) {
    return queryInterface.bulkInsert('ages', [
        {
            "age": 10,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()'),
        },
        {
            "age": 11,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 12,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 13,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 14,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 15,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 16,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 17,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 18,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 19,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 20,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 21,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 22,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 23,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 24,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 25,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 26,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 27,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 28,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 29,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 30,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 31,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 32,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 33,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 34,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 35,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 36,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 37,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 38,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 39,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 40,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 41,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 42,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 43,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 44,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 45,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 46,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 47,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 48,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 49,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 50,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 51,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 52,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 53,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 54,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 55,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 56,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 57,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 58,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 59,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 60,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 61,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 62,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 63,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 64,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 65,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 66,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 67,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 68,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 69,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 70,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 71,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 72,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 73,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 74,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 75,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 76,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 77,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 78,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 79,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 80,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 81,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 82,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 83,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 84,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 85,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 86,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 87,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 88,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 89,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 90,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 91,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 92,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 93,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 94,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 95,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 96,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 97,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 98,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 99,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 100,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 101,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 102,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 103,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 104,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 105,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 106,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 107,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 108,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 109,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 110,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 111,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 112,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 113,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 114,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 115,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 116,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 117,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 118,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 119,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        },
        {
            "age": 120,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()')
        }
    ], {});
  },
  down: function(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('ages', null, {});
  }
};



