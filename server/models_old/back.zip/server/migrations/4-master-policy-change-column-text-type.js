module.exports = {
    up: (queryInterface, Sequelize) => {
        return Promise.all([
            queryInterface.changeColumn('master_policies', 'policy_text', {
                type: Sequelize.TEXT,
                allowNull: true,
            }, {
                
            })
        ])
    },

    down: (queryInterface, Sequelize) => {
        return Promise.all([
            queryInterface.changeColumn('master_policies', 'policy_text', {
                type: Sequelize.STRING,
                allowNull: true,
            }, {
                
            })
        ])
    }
};