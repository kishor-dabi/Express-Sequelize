'use strict';
module.exports = {
  up: function(queryInterface, Sequelize) {
    return queryInterface.bulkInsert('master_policies', [
        {
            "policy_type": 1,
            "policy_text":`Website terms and conditions are vital to the long-term success and security of your online business, as they outline the rules by which you and your users must abide. Without terms, you could be subject to abusive users, intellectual property theft, and unnecessary litigation.

            Our free terms and conditions template will help provide your business with the legal protection it deserves. Download the standard template below, or simply copy and paste the text onto your site.
            
            Alternatively, keep reading to learn more about what a terms and conditions agreement is and how to start writing your own.`,
            "status":1,
            "createdAt": Sequelize.literal('NOW()'),
            "updatedAt": Sequelize.literal('NOW()'),
        }
    ], {});
  },
  down: function(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('master_policies', null, {});
  }
};



