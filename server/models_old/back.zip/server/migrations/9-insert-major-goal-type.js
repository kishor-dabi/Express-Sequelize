'use strict';
module.exports = {
  up: function(queryInterface, Sequelize) {
    return queryInterface.bulkInsert('major_goal_types', 
        [
            {
                "major_goal_name":"Weight Loss",
                "goal_icon":"https://image.flaticon.com/icons/png/128/787/787308.png",
                "createdAt": Sequelize.literal('NOW()'),
                "updatedAt": Sequelize.literal('NOW()')
            },
            {
                "major_goal_name":"Weight Maintain",
                "goal_icon":"https://image.flaticon.com/icons/png/128/787/787308.png",
                "createdAt": Sequelize.literal('NOW()'),
                "updatedAt": Sequelize.literal('NOW()')
            },
            {
                "major_goal_name":"Weight Gain",
                "goal_icon":"https://image.flaticon.com/icons/png/128/787/787308.png",
                "createdAt": Sequelize.literal('NOW()'),
                "updatedAt": Sequelize.literal('NOW()')
            }
        ]
    , {});
  },
  down: function(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('major_goal_types', null, {});
  }
};





