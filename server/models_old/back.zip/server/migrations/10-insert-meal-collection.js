'use strict';
module.exports = {
  up: function(queryInterface, Sequelize) {
    return queryInterface.bulkInsert('meal_collections', 
        [
            {
                "meal_collection_name":"Vegan",
                "meal_type_logo_url":"https://image.flaticon.com/icons/png/128/633/633652.png",
                "bigo_collections":"292",
                "createdAt": Sequelize.literal('NOW()'),
                "updatedAt": Sequelize.literal('NOW()')
            },
            {
                "meal_collection_name":"Vegetarian",
                "meal_type_logo_url":"https://image.flaticon.com/icons/png/128/633/633652.png",
                "bigo_collections":"98,294,104",
                "createdAt": Sequelize.literal('NOW()'),
                "updatedAt": Sequelize.literal('NOW()')
            },
            {
                "meal_collection_name":"Happy to eat anything",
                "meal_type_logo_url":"https://image.flaticon.com/icons/png/128/633/633652.png",
                "bigo_collections":"110,301,295,292,293,349,49,313",
                "createdAt": Sequelize.literal('NOW()'),
                "updatedAt": Sequelize.literal('NOW()')
            }
        ]
    , {});
  },
  down: function(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('meal_collections', null, {});
  }
};

