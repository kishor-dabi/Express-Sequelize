'use strict';
module.exports = {
  up: function(queryInterface, Sequelize) {
    return queryInterface.bulkInsert('heights', [
        {
          "height": 10,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 11,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 12,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 13,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 14,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 15,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 16,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 17,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 18,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 19,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 20,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 21,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 22,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 23,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 24,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 25,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 26,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 27,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 28,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 29,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 30,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 31,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 32,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 33,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 34,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 35,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 36,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 37,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 38,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 39,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 40,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 41,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 42,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 43,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 44,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 45,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 46,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 47,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 48,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 49,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 50,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 51,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 52,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 53,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 54,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 55,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 56,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 57,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 58,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 59,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 60,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 61,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 62,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 63,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 64,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 65,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 66,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 67,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 68,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 69,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 70,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 71,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 72,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 73,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 74,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 75,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 76,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 77,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 78,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 79,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 80,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 81,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 82,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 83,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 84,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 85,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 86,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 87,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 88,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 89,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 90,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 91,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 92,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 93,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 94,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 95,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 96,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 97,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 98,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 99,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 100,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 101,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 102,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 103,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 104,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 105,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 106,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 107,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 108,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 109,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 110,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 111,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 112,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 113,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 114,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 115,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 116,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 117,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 118,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 119,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 120,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 121,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 122,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 123,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 124,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 125,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 126,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 127,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 128,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 129,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 130,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 131,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 132,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 133,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 134,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 135,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 136,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 137,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 138,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 139,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 140,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 141,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 142,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 143,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 144,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 145,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 146,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 147,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 148,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 149,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 150,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 151,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 152,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 153,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 154,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 155,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 156,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 157,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 158,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 159,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 160,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 161,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 162,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 163,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 164,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 165,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 166,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 167,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 168,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 169,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 170,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 171,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 172,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 173,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 174,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 175,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 176,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 177,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 178,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 179,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 180,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 181,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 182,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 183,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 184,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 185,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 186,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 187,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 188,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 189,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 190,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 191,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 192,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 193,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 194,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 195,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 196,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 197,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 198,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 199,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        {
          "height": 200,
          "unit": "cm",
          "createdAt": Sequelize.literal('NOW()'),
          "updatedAt": Sequelize.literal('NOW()')
        },
        
      ], {});
  },
  down: function(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('heights', null, {});
  }
};