const user = require('./user.controller');

module.exports = {
    user,
}