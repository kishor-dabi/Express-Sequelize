
const sendResponse = require('../services/response.service').response;
const User = require('../models').User;
const OTP = require('../models').OTP;
const models = require('../models');
const to = require('await-to-js').default;
const decoded_jwt = require('../services/jwt_token.service').decoded_jwt;



const getPersonalDetailSave = async(req, res) => {
    let userUpdate, error, reqBody = req.body;
    [error, tokenData] = await to(decoded_jwt(req))

    if (error) {
        return sendResponse(res, 400, false,"token decode error" ,error);
    }

    let tokenUserData = tokenData.decoded ? tokenData.decoded.data : null;

    if (!reqBody.gender) {
        return sendResponse(res, 400, false, "Gender is required.");
    }
    if (!reqBody.height_id) {
        return sendResponse(res, 400, false, "Height is required.");
    }
    if (!reqBody.age) {
        return sendResponse(res, 400, false, "Age is required.");
    }
    if (!reqBody.weight_id) {
        return sendResponse(res, 400, false, "Weight is required.");
    }
    if (!reqBody.level_of_exercise_id) {
        return sendResponse(res, 400, false, "Level of exercise is required.");
    }

    reqBody.user_steps = 1;

   let [Updateerror, updateuser] =  await to(User.update(reqBody,{
        where: {
            user_id:tokenUserData.user_id
        }
    }));
    // console.log(error, "-------------=========================-" , updateuser)
    // [error, userData] = await to(models.User.findAll());
    if (Updateerror) {
        return sendResponse(res, 400, false,"Error" ,Updateerror)
    }
  
    // console.log(error, JSON.stringify(tokenData));
   return sendResponse(res, 200,false, "success", updateuser )
}

module.exports.getPersonalDetailSave = getPersonalDetailSave;


const getLoginUserDetails = async(req, res) => {
    let userProfileData, tokenData, error, reqBody = req.body;
    [error, tokenData] = await to(decoded_jwt(req))

    if (error) {
        return sendResponse(res, 400, false,"token decode error" ,error);
    }

    let tokenUserData = tokenData.decoded ? tokenData.decoded.data : null;
    
    // console.log();
   [error, userProfileData] =  await to(User.findOne({
        where: {
            user_id:tokenUserData.user_id
        }
    }));
    console.log(error, "-------------=========================-" , userProfileData)
    // [error, userData] = await to(models.User.findAll());
    if (error) {
        return sendResponse(res, 400, false,"Error" ,error)
    }
  
    // console.log(error, JSON.stringify(tokenData));
   return sendResponse(res, 200,false, "success", userProfileData )
}

module.exports.getLoginUserDetails = getLoginUserDetails;


const saveUserMajorGoal = async(req, res) => {
    let userUpdate, error, reqBody = req.body;
    [error, tokenData] = await to(decoded_jwt(req))

    if (error) {
        return sendResponse(res, 400, false,"token decode error" ,error);
    }

    let tokenUserData = tokenData.decoded ? tokenData.decoded.data : null;

    if (!reqBody.major_goal_type_id) {
        return sendResponse(res, 400, false, "Goal is required.");
    }
    

    reqBody.user_steps = 2;

   let [Updateerror, updateuser] =  await to(User.update(reqBody,{
        where: {
            user_id:tokenUserData.user_id
        }
    }));
    // console.log(error, "-------------=========================-" , updateuser)
    // [error, userData] = await to(models.User.findAll());
    if (Updateerror) {
        return sendResponse(res, 400, false,"Error" ,Updateerror)
    }
  
    // console.log(error, JSON.stringify(tokenData));
   return sendResponse(res, 200,false, "success", updateuser )
}

module.exports.saveUserMajorGoal = saveUserMajorGoal;


const saveGoalWeight = async(req, res) => {
    let userUpdate, error, reqBody = req.body;
    [error, tokenData] = await to(decoded_jwt(req))

    if (error) {
        return sendResponse(res, 400, false,"token decode error" ,error);
    }

    let tokenUserData = tokenData.decoded ? tokenData.decoded.data : null;

    if (!reqBody.goal_weight_id) {
        return sendResponse(res, 400, false, "Goal Weigth is required.");
    }
    

    reqBody.user_steps = 3;

   let [Updateerror, updateuser] =  await to(User.update(reqBody,{
        where: {
            user_id:tokenUserData.user_id
        }
    }));
    // console.log(error, "-------------=========================-" , updateuser)
    // [error, userData] = await to(models.User.findAll());
    if (Updateerror) {
        return sendResponse(res, 400, false,"Error" ,Updateerror)
    }
  
    // console.log(error, JSON.stringify(tokenData));
   return sendResponse(res, 200,false, "success", updateuser )
}

module.exports.saveGoalWeight = saveGoalWeight;



// bcrypt.hash(myPlaintextPassword, saltRounds, function(err, hash) {
//     // Store hash in your password DB.
// });


// Retrieve all user from the database.
// exports.getAllUsers = (req, res) => {
//     try {

//         const userCollection = User.findAll({
//             include: "accounts"
//         }).then(data => {
//             // console.log(data)
//             res.status(200).send(data);
//         });
//         // console.log(userCollection)
//         // return res.status(201).send(userCollection ?  userCollection : []);

//     }
//     catch (e) {
//         console.log(e);

//         res.status(500).send(e);
//     }
// };



