
const sendResponse = require('../services/response.service').response;
const User = require('../models').User;
const OTP = require('../models').OTP;
const models = require('../models');
const to = require('await-to-js').default;
const decoded_jwt = require('../services/jwt_token.service').decoded_jwt;



const getPersonalDetailMasterData = async(req, res) => {
    let ageData,weightData,heightDate,levelOfExerciseData, error;
    // [error, tokenData] = await to(decoded_jwt(req))

    [error, ageData] = await to(models.Age.findAll());
    if (error) {
        return sendResponse(res, 400, false, error)
    }

    [error, weightData] = await to(models.Weight.findAll({order: [
        // ['id', 'DESC'],
        // ['weight', 'ASC'],
        ],
        attributes: ['weight_id','weight' ,'unit']
    },
    ));
    if (error) {
        return sendResponse(res, 400, false, error)
    }

    [error, heightDate] = await to(models.Height.findAll({
        attributes: ['height_id','height' ,'unit']
    }));
    if (error) {
        return sendResponse(res, 400, false, error)
    }

    [error, levelOfExerciseData] = await to(models.LevelOfExercise.findAll());
    if (error) {
        return sendResponse(res, 400, false, error)
    }
    let responseData = {
        heights:heightDate,
        weights:weightData,
        ages:ageData,
        level_of_exercises:levelOfExerciseData
    }

    // console.log(error, JSON.stringify(tokenData));
    sendResponse(res, 200,false, "success" ,responseData)
}

module.exports.getPersonalDetailMasterData = getPersonalDetailMasterData;


const getMajorGoals = async(req, res) => {
    let majorGoalData, error;
    // [error, tokenData] = await to(decoded_jwt(req))

    [error, majorGoalData] = await to(models.MajorGoalTypes.findAll({
        attributes: ['major_goal_type_id','major_goal_name' ,'goal_icon']
    },
    ));
    if (error) {
        return sendResponse(res, 400, false, error)
    }
    // console.log(error, JSON.stringify(tokenData));
    sendResponse(res, 200,false, "success" ,majorGoalData)
}

module.exports.getMajorGoals = getMajorGoals;


const getWeightList = async(req, res) => {
    let majorGoalData, error;
    // [error, tokenData] = await to(decoded_jwt(req))

    [error, majorGoalData] = await to(models.Weight.findAll({
        attributes: ['weight_id','weight' ,'unit']
    },
    ));
    if (error) {
        return sendResponse(res, 400, false, error)
    }
    // console.log(error, JSON.stringify(tokenData));
    sendResponse(res, 200,false, "success" ,majorGoalData)
}

module.exports.getWeightList = getWeightList;


const getMealCollectiontList = async(req, res) => {
    let mealCollectionData, error;
    // [error, tokenData] = await to(decoded_jwt(req))

    [error, majorGoalData] = await to(models.MealCollection.findAll({
        attributes: ['meal_collection_id','meal_collection_name' ,'meal_type_logo_url','bigo_collections']
    },
    ));
    if (error) {
        return sendResponse(res, 400, false, error)
    }
    // console.log(error, JSON.stringify(tokenData));
    sendResponse(res, 200,false, "success" ,majorGoalData)
}

module.exports.getMealCollectiontList = getMealCollectiontList;

