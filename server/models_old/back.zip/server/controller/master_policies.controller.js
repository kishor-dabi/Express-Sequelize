
const sendResponse = require('../services/response.service').response;
const User = require('../models').User;
const OTP = require('../models').OTP;
const models = require('../models');
const to = require('await-to-js').default;
const decoded_jwt = require('../services/jwt_token.service').decoded_jwt;



const getTermsAndCondition = async(req, res) => {
    let policyData, error, reqBody = req.body;
    // [error, tokenData] = await to(decoded_jwt(req))

    [error, policyData] = await to(models.MasterPolicy.findOne({
        where: {
            policy_type:1 
        }
    }));
    if (error) {
        return sendResponse(res, 400, false, error)
    }

    if (!policyData) {
        return sendResponse(res, 404,false, "no data available" ,policyData)
        
    }

    // console.log(error, JSON.stringify(tokenData));
    sendResponse(res, 200,false, "success" ,policyData)
}
module.exports.getTermsAndCondition = getTermsAndCondition;
