
var router = require("express").Router();
const masterPolicyController = require('../controller/master_policies.controller');

router.get('/terms-and-condition',masterPolicyController.getTermsAndCondition);

module.exports = router;
