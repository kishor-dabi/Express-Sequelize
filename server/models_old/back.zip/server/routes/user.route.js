
var router = require("express").Router();
const userController = require('../controller/user.controller');

router.post('/user-details',userController.getPersonalDetailSave);
router.get('/user-profile',userController.getLoginUserDetails);
router.put('/user-goal-save',userController.saveUserMajorGoal);
router.put('/save-goal-weight',userController.saveGoalWeight);


module.exports = router;
