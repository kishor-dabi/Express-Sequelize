// const userController = require('../controller/user.js');
// const otpVarification = require('../controller/otp_varification.js');
// const { route } = require('./outh.route');
module.exports = (app) => {

    var router = require("express").Router();
    var authRoute = require('./outh.route')
    var policyRoute = require('./master_policies.route')
    var masterDataRoute = require('./master_data.route')
    var userRoute = require('./user.route')

    app.get('/test-api', (req, res) => {
        res.status(200).send({
            data: "Welcome Node Sequlize API v1"
        })
    })

    // router.get('/users',userController.getAllUsers);


    // router.put('/user/:userId',userController.update);
    // router.get('/user/:id',userController.getUserById);


    router.use('', authRoute);
    router.use('/policy', policyRoute);
    router.use('/master-data', masterDataRoute);
    router.use('/user', userRoute);
    


    // router.post('/api/signup', )

    app.use("/api", router);

}