
var router = require("express").Router();
const masterController = require('../controller/master_data.controller');

router.get('/get-master-data',masterController.getPersonalDetailMasterData);
router.get('/goals',masterController.getMajorGoals);
router.get('/weights',masterController.getWeightList);
router.get('/meals-type',masterController.getMealCollectiontList);


module.exports = router;
