module.exports.response = (res, status, success, message, data) => {
    let send = {
        success,
        message,
        response: data,
        status
    }
    return res.json(send);
}