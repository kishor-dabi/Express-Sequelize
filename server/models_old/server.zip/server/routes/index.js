const userController = require('../controller/user.js');
const accountController = require('../controller/account.js');
const loginController = require('../controller/login.js');
module.exports = (app) => {

    var router = require("express").Router();
  

    app.get('/api',(req,res) => {
        res.status(200).send({
            data : "Welcome Node Sequlize API v1"
        })
    })

    router.get('/users',userController.getAllUsers);


    router.put('/user/:userId',userController.update);
    router.get('/user/:id',userController.getUserById);


    router.post('/account/create',accountController.create);

    router.put('/account/:id',accountController.update);
    router.get('/accounts',accountController.getAll);
    router.post('/login',loginController.login);
    router.post('/signup',loginController.signup);

    // router.post('/api/signup', )

 app.use("/api", router);

}