const user = require('./user');
const account = require('./account');

module.exports = {
    user,
    account
}