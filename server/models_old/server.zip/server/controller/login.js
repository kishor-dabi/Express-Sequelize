const User = require('../models').User;
const OTP = require('../models').OTP;

const bcrypt = require('bcrypt');
const saltRounds = 10;
var jwt = require('jsonwebtoken');

const env = process.env.NODE_ENV || 'development';

const config = require(__dirname + '/../config/config.json')[env];


// Retrieve all user from the database.
exports.login = (req, res) => {
    try {
            const userCollection =  User.find({
                where: { email: req.body.email },
                // include: "accounts"
            }).then(data=>{
               
                bcrypt.compare(req.body.password, data.password).then(function(result) {
                    // result == true
                    if (result) {
                        // let user_data = JSON.parse(JSON.stringify(data))
                        let user_data = JSON.parse(JSON.stringify(data));
                        delete user_data.password;

                        let token = jwt.sign({
                            exp: Math.floor(Date.now() / 1000) + ((config.jwt_expiry_days || 1)*24*60 * 60),
                            data: user_data
                            }, config.jwt);
                           
                        // var token = jwt.sign(JSON.stringify(user_data), config.jwt, { algorithm: 'RS256'}).catch(err1=>console.log(err1));
                        // jwt.sign(user_data, config.jwt, { algorithm: 'RS256' }, function(err, token) {
                        //     if (!err) {
                                console.log(token, "-----------token")
                                res.status(200).send({token:token, user_data:user_data});
                            // }else{
                                // console.log(err, "------------")
                            // }
                        // });
                    }else{
                        res.status(400).send({message:"Invalid email or password"});
                    }
                });
                
                // res.status(200).send(data);
            });
            // console.log(userCollection)
            // return res.status(201).send(userCollection ?  userCollection : []);

        }
        catch(e){
            console.log(e);

            res.status(500).send(e);
        }
  };


exports.signup = (req, res) =>{
    try {
            let body = req.body;
            User.find({
                  where: {
                    email : req.body.email
                }
            }).then(data=>{
                console.log(JSON.stringify(data))
                if (data) {
                        res.status(500).send({message:'User already exist with this email'});
                } else {
                    bcrypt.hash(req.body.password, saltRounds, function(err, hash)  {
                    // Store hash in your password DB.
                    if (!err) {
                         console.log(hash)
                        body.password = hash;

                        const userCollection =  User
                            .create( 
                                body
                            ).then(data=>{
                                OTP.create({
                                    user_id:data.user_id,
                                    otp_for:1,
                                    status:1,
                                    otp: Math.floor(100000 + Math.random() * 900000)
                                }).then((otpdata)=>{
                                    console.log(otpdata);
                                    res.status(201).send(data);
                                })
                            }).catch((err)=>{
                                res.status(500).send(err);
                            });
                        
                    }else{
                        res.status(500).send(err);
                    }
                }); 
                }
            });
            
        }
        catch(e){
            console.log(e);
            res.status(400).send(e);
        }
           
}